package com.telstra.codechallenge.starred;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.telstra.codechallenge.starred.StarredRepo;

@RestController
public class StarredRepoController {

	  private StarredRepoService starredRepoService;
	  
	  public StarredRepoController(
			  StarredRepoService starredRepoService) {
	    this.starredRepoService = starredRepoService;
	  }
	
	  @RequestMapping(path = "/starred/{num}", method = RequestMethod.GET)
	  public List<StarredRepo> repos(@PathVariable Long num) {
		  try {
			  if(num<0)
				  throw new NullPointerException("Number cannot be less than zero");
			  
			  if(starredRepoService.getStarredRepo().getStatusCode() != HttpStatus.OK)
				  throw new Exception("Bad Response recieved");
			  if(starredRepoService.getStarredRepo().hasBody()) {
				  StarredRepo[] repositories = starredRepoService.getStarredRepo().getBody().getItems();
				  List<StarredRepo> list = Arrays.asList(repositories);
				  List<StarredRepo> output = list.stream().limit(num).collect(Collectors.toList());
				  return output;
			  }
			  else {
				  throw new Exception("No output recieved");
			  }
	    }catch(NullPointerException e) {
	    	List<StarredRepo> output = new ArrayList<>(); 
	    	return output;
	    }catch(Exception e) {
	    	List<StarredRepo> output = new ArrayList<>(); 
	    	return output;
	    }
		  
		  
	  }
	  
}
