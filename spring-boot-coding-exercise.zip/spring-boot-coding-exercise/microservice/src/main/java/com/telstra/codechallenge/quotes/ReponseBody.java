package com.telstra.codechallenge.quotes;

public class ReponseBody {
	
	private Long total_count;
	private Boolean incomplete_results;
	private StarredRepo[] items;
	
	
	public ReponseBody() {
		super();
	}
	public ReponseBody(Long total_count, Boolean incomplete_results, StarredRepo[] items) {
		super();
		this.total_count = total_count;
		this.incomplete_results = incomplete_results;
		this.items = items;
	}
	public Long getTotal_count() {
		return total_count;
	}
	public void setTotal_count(Long total_count) {
		this.total_count = total_count;
	}
	public Boolean getIncomplete_results() {
		return incomplete_results;
	}
	public void setIncomplete_results(Boolean incomplete_results) {
		this.incomplete_results = incomplete_results;
	}
	public StarredRepo[] getItems() {
		return items;
	}
	public void setItems(StarredRepo[] items) {
		this.items = items;
	}
}
