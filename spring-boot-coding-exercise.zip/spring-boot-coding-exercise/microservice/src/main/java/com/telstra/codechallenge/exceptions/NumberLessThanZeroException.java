package com.telstra.codechallenge.exceptions;

public class NumberLessThanZeroException extends Exception {

	public NumberLessThanZeroException(String e) {
		super(e);
	}
}
