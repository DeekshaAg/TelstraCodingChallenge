package com.telstra.codechallenge.quotes;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
public class SpringBootQuotesService {

  @Value("${quotes.base.url}")
  private String quotesBaseUrl;

  private RestTemplate restTemplate;

  public SpringBootQuotesService(RestTemplate restTemplate) {
    this.restTemplate = restTemplate;
  }

  /**
   * Returns an array of spring boot quotes. Taken from https://spring.io/guides/gs/consuming-rest/.
   *
   * @return - a quote array
   */
  public Quote[] getQuotes() {

    return restTemplate.getForObject(quotesBaseUrl + "/api", Quote[].class);
  }

  /**
   * Returns a random spring boot quote. Taken from https://spring.io/guides/gs/consuming-rest/.
   *
   * @return - a quote
   */
  public Quote getRandomQuote() {
    return restTemplate.getForObject(quotesBaseUrl + "/api/random", Quote.class);
  }
  
  /*
   * To get the highest starred repositories of the last week* 
   */
  public ResponseEntity<ReponseBody> getStarredRepo(Long num) {
	  
	  String date =java.time.LocalDate.now().minusDays(7).toString();
	  Long num_of_pages = num / 40 +1;
	  String url = "https://api.github.com/search/repositories?q= created:>"+date+"&sort=stars&order=desc&page="+num_of_pages.toString()+"&per_page=40";
	  
	  
	  return restTemplate.getForEntity(url, ReponseBody.class);
  }
}
