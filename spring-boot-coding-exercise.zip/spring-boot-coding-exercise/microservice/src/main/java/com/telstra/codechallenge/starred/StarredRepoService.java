package com.telstra.codechallenge.starred;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.telstra.codechallenge.starred.ResponseBody;

@Service
public class StarredRepoService {
	
	  @Value("${starred.base.url}")
	  private String starredBaseUrl;
	  
	  @Autowired
	  private RestTemplate restTemplate;
	  
	  
	  /*
	   * To get the highest starred repositories of the last week* 
	   */
	  
	  public ResponseEntity<ResponseBody> getStarredRepo() {
		  
		  try {
			  String date =java.time.LocalDate.now().minusDays(7).toString();
			  
		  	  String  url = starredBaseUrl+"/search/repositories?q= created:>"+date+"&sort=stars&order=desc";
			  if(url=="")
				  throw new NullPointerException("Empty url");
		  	  return restTemplate.getForEntity(url, ResponseBody.class);
		  }catch(NullPointerException e) {
			  
			  HttpHeaders headers = new HttpHeaders();
			  headers.set("Reason", "Incorrect URL");
			  return new ResponseEntity<ResponseBody>(null,headers,HttpStatus.BAD_REQUEST);
		  }catch(Exception e) {
			 
			  HttpHeaders headers = new HttpHeaders();
			  headers.set("Reason", "Some Internal Error occured");
			  return new ResponseEntity<ResponseBody>(null,headers,HttpStatus.BAD_REQUEST);
		  }
		  }
}
