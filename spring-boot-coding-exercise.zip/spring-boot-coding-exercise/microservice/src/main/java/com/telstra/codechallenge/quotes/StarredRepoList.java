package com.telstra.codechallenge.quotes;

import java.util.ArrayList;
import java.util.List;

public class StarredRepoList {
	
	private List<StarredRepo> list;

	public List<StarredRepo> getList() {
		return list;
	}

	public void setList(List<StarredRepo> list) {
		this.list = list;
	}

	public StarredRepoList() {
		super();
	}

	public StarredRepoList(List<StarredRepo> list) {
		super();
		this.list = list;
	} 
	
	

}
