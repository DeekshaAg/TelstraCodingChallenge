package com.telstra.codechallenge.exceptions;

public class BadResponseException extends Exception{

	public BadResponseException(String e) {
		super(e);
	}
}
